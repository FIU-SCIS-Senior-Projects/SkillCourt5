public class colour
{
  public int r;
  public int g;
  public int b;
  
  public colour(int r, int g, int b)
  {
    this.r = r;
    this.g = g;
    this.b = b;
    
  }
  
  public int getRed()
  {
     return r;
  }
  public int getGreen()
  {
    return g;
  }
  public int getBlue()
  {
    return b;
  }
  
}